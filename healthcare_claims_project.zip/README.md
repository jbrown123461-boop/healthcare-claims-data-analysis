# Healthcare Claims Data Analysis

## Overview
This project analyzes healthcare claims data to identify trends, inefficiencies, and key drivers of claim denials.

## Tools Used
- Python (Pandas, Matplotlib)
- SQL

## Key Insights
- ~20% of claims denied due to missing information
- Processing time higher for denied claims

## Author
Jasmin Brown
