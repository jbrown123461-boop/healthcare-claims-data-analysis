SELECT claim_status, COUNT(*) FROM claims_data GROUP BY claim_status;
SELECT AVG(processing_days) FROM claims_data;
